var table = document.getElementById("StudentData");



// const btn = document.getElementsByClassName('btn1');
// btn.addEventListener('click', function onClick(event) {
//   event.target.style.backgroundColor = 'red';
// });


var id = 6;
function addNewData() {
    
    
    var row = table.insertRow(-1);
    var No = row.insertCell(0);
    var Stu_Name = row.insertCell(1);
    var Subject = row.insertCell(2);
    var Marks = row.insertCell(3);
    var Status = row.insertCell(4);
    var Action = row.insertCell(5);
    No.setAttribute("data-label","No")
    Stu_Name.setAttribute("data-label","Name")
    Subject.setAttribute("data-label","Subject")
    Marks.setAttribute("data-label","Marks")
    Status.setAttribute("data-label","Status")
    No.innerHTML = id++;
    Stu_Name.innerHTML = '<input type="text" id="stu_name" pattern="[a-zA-Z]+" title="Take only Alphabets !" maxlength = "12" required >';
    Subject.innerHTML = '<input type="text" id="subject" pattern="[a-zA-Z]+"  title="Take only Alphabets !" maxlength = "12" required >';
    Marks.innerHTML = '<input type="number" id="marks" pattern="[0-9]+" min="0" max="100" required >';
    Status.innerHTML = '<a class="btn btn-success btn1 me-1" id="btn_pass" onclick="passbtn(this)">Pass</a><a class="btn btn-danger btn2" onclick="failbtn(this)">Fail</a>';
    Action.innerHTML = '<button class="btn " type="button"  onclick="deleteData(this)"><span> <img src="image/remove.jpg" w-100 class="rounded-circle" alt=""> </span></button>';
    
  }

  function Data(){
    SubmitData(this)
    per_Data() 

    return false
  }
  
  function SubmitData() {
    let result=document.getElementById("ResultData");
    result.innerHTML=` <tr class="bg-info text-dark">
    <th >No</th>
    <th >Student Name</th>
    <th >Subject</th>
    <th>Marks</th>
    <th>Result</th>
    </tr> 
    `
   

    let stu_Name_arr = [];
    let Stu_Name=document.querySelectorAll("#stu_name");
    for(i=0;i<Stu_Name.length;i++){
      stu_Name_arr.push(Stu_Name[i].value);
    }

    let subject_arr = [];
    let Subject=document.querySelectorAll("#subject");
    for(i=0;i<Subject.length;i++){
      subject_arr.push(Subject[i].value);
    }

    let Marks_arr = [];
    let Marks=document.querySelectorAll("#marks");
    for(i=0;i<Marks.length;i++){
      Marks_arr.push(Marks[i].value);
      // let Marks_num= Marks_arr.map(Number);
      // console.log(Marks_num)
    }

  

    for(i=1;i<table.rows.length;i++){
    
      
      let row= result.insertRow(i);
      
      let no_cell=row.insertCell(0);
      let name_cell=row.insertCell(1);
      let subject_cell = row.insertCell(2);
      let marks_cell = row.insertCell(3);
      let Status_cell = row.insertCell(4);

      no_cell.innerHTML = `<p class="counterCell"></p>`;
      name_cell.innerHTML=stu_Name_arr[i-1];
      subject_cell.innerHTML=subject_arr[i-1];
      marks_cell.innerHTML=Marks_arr[i-1];

         
      if(Marks_arr[i-1]<33){
        row.style.background="red";
        Status_cell.innerHTML='Fail';
      }
      else{
        row.style.background="none";
        Status_cell.innerHTML='Pass';
        
      }

    }

    
    return false;
    

  }

  function deleteData(Data){
    
    let confirm1 = confirm("Are you sure you want to delete?");
    if(confirm1){
      
      Data.parentNode.parentNode.remove();
      id--;
      
      for(let i=1;i<table.rows.length;i++){
        
          table.rows[i].cells[0].innerHTML = i;
          
      }
      
      
      }
    }

      
    
  

  
function per_Data(){
let table=document.getElementById("Result_per");
    table.innerHTML=` <tr class="bg-info text-dark">
    <th >No</th>
    <th >Student Name</th>
    <th >Percentage</th>
    </tr> 
    `
  let stu_Name_arr = [];
    let Stu_Name=document.querySelectorAll("#stu_name");
    for(i=0;i<Stu_Name.length;i++){
      stu_Name_arr.push(Stu_Name[i].value);
    }

    let subject_arr = [];
    let Subject=document.querySelectorAll("#subject");
    for(i=0;i<Subject.length;i++){
      subject_arr.push(Subject[i].value);
    }

    let Marks_arr = [];
    let Marks=document.querySelectorAll("#marks");
    for(i=0;i<Marks.length;i++){
      Marks_arr.push(Marks[i].value);
    }


  let StudentData = [];
  for (let index = 0; index < stu_Name_arr.length; index++) {
    let object = { name:"", mark:"" }
    object.name = stu_Name_arr[index];
    object.mark = Number.parseInt(Marks_arr[index]);
    StudentData.push(object);
  }
 

    const resp = StudentData.reduce((arr, ele) => {
      const reduce_dupp_stu = arr.find(x => x.name === ele.name);
      if(!reduce_dupp_stu) return arr.concat(ele);
      return (reduce_dupp_stu.mark += ele.mark, arr);
    },[]);

    // console.log(resp);
    const arr = stu_Name_arr;
    const counts = {};
    for (const num of arr) {
      counts[num] = counts[num] ? counts[num] + 1 : 1;
    }

    // console.log(counts);
    resp.forEach(display => {
      display.mark /= counts[display.name];
    });

    // console.log(resp);
    // let table = document.getdisplayById("Result_per");
    resp.forEach(display => {
      let row = table.insertRow(table.length);
      cell0 = row.insertCell(0).classList.add("counterCell");
      cell1 = row.insertCell(1).innerHTML = display.name;
      cell2 = row.insertCell(2).innerHTML = display.mark + "%";
    });

}




  function Search() {
    var input, filter, table, tr, name, subject, i, txtValue1 ,txtValue2;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("ResultData");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      name = tr[i].getElementsByTagName("td")[1];
      subject = tr[i].getElementsByTagName("td")[2];

      
      if (name || subject ) {
        name = name.innerText;
        subject = subject.innerText;

        if ((name.toUpperCase().startsWith(filter) ) || (subject.toUpperCase().startsWith(filter))) {
          tr[i].style.display = "";
          
        } else {
          tr[i].style.display = "none";
        }
      }   
    }
  }
   
  function sortTable(n) {
    var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
    table = document.getElementById("ResultData");
    switching = true;

    dir = "asc"; 

    while (switching) {
   
      switching = false;
      rows = table.rows;
   
      for (i = 1; i < (rows.length - 1); i++) {
       
        shouldSwitch = false;
    
        x = rows[i].getElementsByTagName("TD")[n];
        y = rows[i + 1].getElementsByTagName("TD")[n];
      
        if (dir == "asc") {
          if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
           
            shouldSwitch= true;
            break;
          }
        } 
        
      }
      if (shouldSwitch) {
   
        rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
        switching = true;
      
        switchcount ++;      
      } else {
       
        if (switchcount == 0 && dir == "asc") {
          dir = "desc";
          switching = true;
        }
      }
    }
    // return false;
  }



  function passbtn(e){
    if(e.classList.contains("btn1"))
    {
      e.classList.add("Pass")
      e.nextElementSibling.classList.remove("Fail");
    }
  }
  function failbtn(e){
    if(e.classList.contains("btn2"))
    {
      e.classList.add("Fail")
      e.previousElementSibling.classList.remove("Pass");
    }
  }
 