var table = document.getElementById("StudentData");

var id = 6;
function addNewData() {
    
    
    var row = table.insertRow(-1);
    var No = row.insertCell(0);
    var Stu_Name = row.insertCell(1);
    var Subject = row.insertCell(2);
    var Marks = row.insertCell(3);
    var Status = row.insertCell(4);
    var Action = row.insertCell(5);
    No.setAttribute("data-label","No")
    Stu_Name.setAttribute("data-label","Name")
    Subject.setAttribute("data-label","Subject")
    Marks.setAttribute("data-label","Marks")
    Status.setAttribute("data-label","Status")
    No.innerHTML = id++;
    Stu_Name.innerHTML = '<input type="text" id="stu_name" pattern="[a-zA-Z]+" title="Take only Alphabets !" maxlength = "12" required >';
    Subject.innerHTML = '<input type="text" id="subject" pattern="[a-zA-Z]+"  title="Take only Alphabets !" maxlength = "12" required >';
    Marks.innerHTML = '<input type="number" id="marks" pattern="[0-9]+" min="0" max="100" required >';
    Status.innerHTML = '<a class="btn btn-success btn1 me-1" id="btn_pass">Pass</a><a class="btn btn-danger btn2">Fail</a>';
    Action.innerHTML = '<button class="btn " type="button"  onclick="deleteData(this)"><span> <img src="image/remove.jpg" w-100 class="rounded-circle" alt=""> </span></button>';
    
  }

  function Data(){
    SubmitData()
 

    return false
  }
  

  function deleteData(Data){
    
    // let confirm1 = confirm("Are you sure you want to delete?");
    // if(confirm1){
      Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes!'
      }).then((result) => {
        if (result.isConfirmed) {
          Swal.fire(
            'Deleted!',
            'Deleted Successfully.',
            'success'
          )
      Data.parentNode.parentNode.remove();
      id--;
      
      for(let i=1;i<table.rows.length;i++){
        
          table.rows[i].cells[0].innerHTML = i;
          
      }
      //  SubmitData();
      
      
      }
    })

      
    
  }
 