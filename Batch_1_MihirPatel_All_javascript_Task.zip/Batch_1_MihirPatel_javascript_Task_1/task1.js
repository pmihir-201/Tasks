var div = document.getElementById("table1").innerHTML;

  function addNewRow() {
    var table = document.getElementById("table1");
    if(table.rows.length <= 5){
    var row = table.insertRow(-1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    cell1.setAttribute("data-label","First Name")
    cell2.setAttribute("data-label","Last Name")
    cell3.setAttribute("data-label","Action")
    cell1.innerHTML = '<input type="text" placeholder="First Name">';
    cell2.innerHTML = '<input type="text" placeholder="Last Name">';
    cell3.innerHTML = '<button class="btn btn-danger" id="btn1" onclick="deleteRow(this)"><span> del | - | </span></button>';
    }
    else{
        alert("Limits reach to Add Records");
        document.getElementById("btn3").disabled = true;
    }
  }

  function deleteRow(element){
    if(element){
        element.parentNode.parentNode.remove();
        document.getElementById("btn3").disabled = false;
    }
  }

  function refresh(){
   
      document.getElementById("table1").innerHTML="";
      document.getElementById("table1").innerHTML=div;
      document.getElementById("btn3").disabled = false;
      
     
    
  }