 $(document).ready(function (){
 var div= $('#tbody').html();
  //Add row
  var tbody = $('#AddRow').children('tbody');
  $('#btn1').click(function(){  
  let table = tbody.length ? tbody : $('#AddRow');
      if($('#tbody').children().length<=5){
       table.append(' <tr><td data-label="First Name"><input type="text" value="" placeholder="First Name"></td><td data-label="Last Name"><input type="text" value="" placeholder="Last Name"></td><td data-label="Action"><button class="btn btn-danger del" id="del" ><span> del | - | </span></button></td></tr>');
      } else{
        alert("Limits reach to Add Records");
        $("#btn1").attr("disabled",true); 
      }
  })
  //Delete Row
    $('#AddRow').on('click','.del',function(){
      let confirm1 = confirm("Are you sure you want to delete?");
      if(confirm1){
          $(this).parent().parent().remove();
          $("#btn1").attr("disabled",false);
        }
    })

    //refresh

    $('.reset1').click(function(){  
      $('#tbody').children().empty();
      $('#tbody').html(div);
      $("#btn1").attr("disabled",false);
     })
  })
