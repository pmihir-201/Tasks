$(document).ready(function () {
  
  $("#btn1").click(function createTable() {
  
   var r_count = $("#row").val();
   var c_count = $("#column").val();
   var x=$('#myTable');
   x.html("")
      var count =0;
        for(var r=0;r<parseInt(r_count);r++){
        
          var y=  x.append($('<tr>'));

              for(var c=0;c<parseInt(c_count);c++)  {
                 
                 y.append($('<td>').text(`${count++}`));
             

              }

        }

  })

})