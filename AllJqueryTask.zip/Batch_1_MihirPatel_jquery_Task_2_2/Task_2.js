function passbtn(e) {
  //console.log(e)
  if ($(e).hasClass("btn1")) {
    $(e).addClass("Pass");
    $(e).next().removeClass("Fail");
  }
}

function failbtn(e) {
  //console.log(e)
  if ($(e).hasClass("btn2")) {
    $(e).addClass("Fail");
    $(e).prev().removeClass("Pass");
  }
}


function validate(){
  let isDataValid=true;

  let onlynum = /^[0-9]+/;
  $("input").each(function(){
    if($(this).val()==""){
      $(this).siblings('span').text("please enter input").css("color","red");
      isDataValid = false;
    }
    else{
      $(this).siblings('span').text("");
       isDataValid=true;

    }
  })

  $("input[type='number']").each(function(){
    if(!($(this).val().match(onlynum))){
      $(this).siblings('span').text("only digit allowed").css("color","red");
      isDataValid = false;
      return false
    }
    else if(Number.parseInt($(this).val())<0||Number.parseInt($(this).val())>100){
      $(this).siblings('span').text("Marks should be between 0 to 100").css("color","red");
      isDataValid = false;
      return false

    }
    else{
      $(this).siblings('span').text("")
       isDataValid=true;

    }
    
  })

  return isDataValid;
 

}





$(document).ready(function () {


  $('.show_data').click(function(){
    
    console.log(validate())
    if(validate()){
   
     resultData();
     PercentageData();
   
   }
   
    
   });

  //Add row
  let tbody = $('#StudentData').children('tbody');
  $('#addNewData').click(function () {

  


    let table = tbody.length ? tbody : $('#StudentData');
    table.append('<tr><td data-label="No"> <p class="counterCell"></p></td>'
      + '<td data-label="Name"><input type="text" class="stu_name" pattern="[a-z A-Z]+" title="Take only Alphabets !" maxlength = "12" placeholder="Enter a Name" required ></input><span class="N_Name"></span></td>'
      + ' <td data-label="Subject"> <input type="text" class="subject" pattern="[a-zA-Z]+"  title="Take only Alphabets !" maxlength = "12" placeholder="Enter a subject" required ><span></span> </td>'
      + '<td data-label="Marks"> <input type="number" class="marks" pattern="[0-9]+" min="0" max="100" placeholder="Enter a Marks" required > <span></span> </td>'
      + '<td data-label="Status"> <a class="btn btn-success btn1 me-1" id="btn_pass"  onclick="passbtn(this)">Accept</a><a class="btn btn-danger btn2" id="btn_fail" onclick="failbtn(this)">Reject</a> </td>'
      + '<td data-label="Action"> <button class="btn delete" type="button" ><span> <img src="image/remove.jpg" w-100 class="rounded-circle" alt=""> </span></button> </td></tr>');
  
  
      validate()
  
    })





  //Delete Row
  $('#StudentData').on('click', '.delete', function () {
    let confirm1 = confirm("Are you sure you want to delete?");
    if (confirm1) { $(this).parent().parent().remove(); }
  })




  //searching the Data...

  $("#myInput").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#ResultData tr").filter(function () {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });



  // sorting Data on Table... By Name
  $("#sortByNameBtn").click(function () {
    var table = $("#ResultData");
    var rows = table.find("tr:gt(0)").toArray().sort(compare(1));
    var asc = true;
    if (!asc) {
      rows = rows.reverse();
    }
    for (var i = 0; i < rows.length; i++) {
      table.append(rows[i]);
    }
    asc = !asc;
  });

  function compare(index) {
    return function (a, b) {
      var valA = getCellValue(a, index);
      var valB = getCellValue(b, index);
      return $.isNumeric(valA) && $.isNumeric(valB) ? valA - valB : valA.localeCompare(valB);
    };
  }

  function getCellValue(row, index) {
    return $(row).children("td").eq(index).html();
  }


  // sorting Data on Table... By Subject
  $("#sortBySubjectBtn").click(function () {
    var table = $("#ResultData");
    var rows = table.find("tr:gt(0)").toArray().sort(compare(2));
    var asc = true;
    if (!asc) {
      rows = rows.reverse();
    }
    for (var i = 0; i < rows.length; i++) {
      table.append(rows[i]);
    }
    asc = !asc;
  });

  function compare(index) {
    return function (a, b) {
      var valA = getCellValue(a, index);
      var valB = getCellValue(b, index);
      return $.isNumeric(valA) && $.isNumeric(valB) ? valA - valB : valA.localeCompare(valB);
    };
  }

  function getCellValue(row, index) {
    return $(row).children("td").eq(index).html();
  }





  // Display Data
function resultData() {

    // var error = "";
    // var name_ip = $(".stu_name");
    // name_ip.each(function (e){
    //   if(name_ip.eq(e).val()==""){
    //     error = "Name Cannot be empty";
    //     name_ip.eq(e).siblings().html(error).css("color","red");
    //     return false;
    //   }
    
    // })
    
    validate()

    var table2 = $('#ResultData')
    table2.html('<tr class="bg-info text-dark"><th >No</th><th id="name_header">Student Name</th><th  id="subject_header">Subject</th><th>Marks</th></tr>');
    console.log(table2);
    let stu_Name_arr = [];
    let Stu_Name = $(".stu_name");
    for (i = 0; i < Stu_Name.length; i++) {
      stu_Name_arr.push(Stu_Name[i].value);
    }

    let subject_arr = [];
    let Subject = $(".subject");
    for (i = 0; i < Subject.length; i++) {
      subject_arr.push(Subject[i].value);
    }

    let Marks_arr = [];
    let Marks = $(".marks");
    for (i = 0; i < Marks.length; i++) {
      Marks_arr.push(Marks[i].value);
    }

    let tablerow = table2.rows;
    // console.log(stu_Name_arr)
    // console.log(subject_arr)
    // console.log(Marks_arr)
  

    var table = $("#StudentData");

    console.log();

    $.each((table).children('tbody').children().children(`td[data-label='Status']`).children('.btn1'), function () {
      if ($(this).hasClass('Pass')) {
        // console.log($(this).closest('tr').children(`td[data-label='Name']`).children('.stu_name').val());
        table2.append('<tr ><td data-label="No"> <p class="counterCell"></p></td>'
          + '<td >' + $(this).closest('tr').children(`td[data-label='Name']`).children('.stu_name').val()
          + '</td><td>' + $(this).closest('tr').children(`td[data-label='Subject']`).children('.subject').val()
          + '</td><td class="m">' + $(this).closest('tr').children(`td[data-label='Marks']`).children('.marks').val()
          + '</td></tr>')
      }
    })

    $('.m').each(function () {
      if ($(this).text() < 33) {
        $(this).parent().css("background", "red")
      }
    })

// return false
  }


  function ProgressCountdown(timeleft) {
    return new Promise((resolve, reject) => {
      var countdownTimer = setInterval(() => {
        timeleft--;
        $('#Bar_Countdown').val(timeleft);
        $('#Text_Countdown').text(timeleft);

        if (timeleft <= 0) {
          clearInterval(countdownTimer);
          $('#ok').click(function () {
            ProgressCountdown(100).then(value => $('#model1').modal('show'));
          })
          resolve(true);
        }
      }, 1000);
    });
  }
  ProgressCountdown(100).then(value => $('#model1').modal('show'));


  // Result in Percentage

  function PercentageData() {
    var table3 = $('#Result_per')
    table3.html('<tr class="bg-info text-dark"><th >No</th><th >Student Name</th><th>Percentage</th></tr>');
    console.log(table3);
    let stu_Name_arr = [];
    let Stu_Name = $(".stu_name");
    for (i = 0; i < Stu_Name.length; i++) {
      stu_Name_arr.push(Stu_Name[i].value);
    }

    let subject_arr = [];
    let Subject = $(".subject");
    for (i = 0; i < Subject.length; i++) {
      subject_arr.push(Subject[i].value);
    }

    let Marks_arr = [];
    let Marks = $(".marks");
    for (i = 0; i < Marks.length; i++) {
      Marks_arr.push(Marks[i].value);
    }

    // let tablerow2=table3.html();
    // console.log(stu_Name_arr)
    // console.log(subject_arr)
    // console.log(Marks_arr)

    var table = $("#StudentData");
    let StudentData = [];
    let tablerow2 = table3.rows;
    $.each((table).children('tbody').children().children(`td[data-label='Status']`).children('.btn1'), function () {
      if ($(this).hasClass('Pass')) {

        let object = { name: "", mark: "" }
        object.name = $(this).closest('tr').children(`td[data-label='Name']`).children('.stu_name').val();
        object.mark = Number.parseInt($(this).closest('tr').children(`td[data-label='Marks']`).children('.marks').val());
        StudentData.push(object);

      }
    })



    const resp = StudentData.reduce((arr, ele) => {
      const reduce_dupp_stu = arr.find(x => x.name === ele.name);
      if (!reduce_dupp_stu) return arr.concat(ele);
      return (reduce_dupp_stu.mark += ele.mark, arr);
    }, []);

    // console.log(resp);
    const arr = stu_Name_arr;
    const counts = {};
    for (const num of arr) {
      counts[num] = counts[num] ? counts[num] + 1 : 1;
    }

    console.log(counts);
    resp.forEach(display => {
      display.mark /= counts[display.name];
    });

    console.log(resp);

    resp.forEach(display => {


      table3.append('<tr ><td data-label="No"> <p class="counterCell"></p></td>'
        + '<td>' + display.name + '</td><td class="m">' + display.mark + "%" + '</td></tr>')

    });

// return false

  }

})


