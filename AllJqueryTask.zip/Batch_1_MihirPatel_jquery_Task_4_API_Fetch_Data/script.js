$(document).ready(function () {

  $("#fetch_data").click(function () {

        $.ajax({
            url: 'API/entries.json',
            method: 'GET',
            dataType: 'json',
            beforeSend: function() {
                $('#loader').removeClass('hidden')
            },
            success:   function (data) {
                var data_1 = '';

                data.entries.forEach((value) => {
                    data_1 += '<tr>';
                    // data_1 += '<td data-label="Id">' + ' <p class="counterCell"></p>' + '</td>';
                    data_1 += '<td data-label="API">' + value.API + '</td>';
                    data_1 += '<td data-label="Description">' + value.Description + '</td>';
                    data_1 += '<td data-label="Auth">' + value.Auth + '</td>';
                    data_1 += '<td data-label="Cors">' + value.Cors + '</td>';
                    data_1 += '<td data-label="Link"><a href=' + value.Link + '>' + value.Link + '</a></td>';
                    data_1 += '<td data-label="Category">' + value.Category + '</td>';
                    data_1 += '<tr>';
                });

                $('#employee_table').append(data_1);

            },
            complete: function(){
                $('#loader').addClass('hidden')
            },
        })
       
    })


})