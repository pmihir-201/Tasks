var table1 = $('#myTable').DataTable(
    {
        type:"get",
        ajax:"entries.json",
       columns:[
        
            {data:'API'},
            {data:'Description'},
            {data:'Auth'},
            {data:'HTTPS'},
            {data:'Cors'},
            {data:'Category'},

        
       ]
    }
)

// $(document).ready(function(){

//     $.ajax({
//         type:"get",
//         url:"https://api.publicapis.org/entries",
//         success:function(e){
//             apicall(e)
//         }
//     })

// })
// function apicall(table){
//     table1.clear();
//     console.log(table.entries[0])
//     table.entries.forEach(element => {
//         table1.row.add(
//             [
//                 element.API,

//                 element.Description,

//                 element.Auth,

//                 element.HTTPS,

//                 element.Cors,

//                 element.Category

//             ]
//         ).draw()
//     })
// }