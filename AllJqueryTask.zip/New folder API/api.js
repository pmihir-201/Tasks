
//  $.ajax({

//         // type: 'GET',

//         // dataType: 'json',

//         // url: "https://api.publicapis.org/entries",

//         // success: function(data){

//         //     $.each(data, function(key, value){

//         //     }



//     })



let table1 = $('#myTable').DataTable();


$(document).ready(function () {

    $.ajax({

        type: "get",

        url: "https://api.publicapis.org/entries",

        success: function (x) {
            apicall(x)

        }

    });


    /* Datatable access by using table ID */

    function apicall(table) {


        table1.clear();

        console.log(

            table.entries[0]

        );

        table.entries.forEach(element => {

            table1.row.add([

                element.API,

                element.Description,

                element.Auth,

                element.HTTPS,

                element.Cors,

                element.Category

            ]).draw();



        });



    }







});