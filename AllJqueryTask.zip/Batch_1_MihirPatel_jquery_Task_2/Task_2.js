      $(document).ready(function (){
          $("#submit").click(function Data(){
              SubmitData()
              return false
          })
      })
    //Add row
      var tbody = $('#StudentData').children('tbody');
      $('#addNewData').click(function(){  
      let table = tbody.length ? tbody : $('#StudentData');
           table.append('<tr><td data-label="No"> <p class="counterCell"></p></td>'
          + '<td data-label="Name"><input type="text" id="stu_name" pattern="[a-z A-Z]+" title="Take only Alphabets !" maxlength = "12" placeholder="Enter a Name" required ></input></td>'
          +' <td data-label="Subject"> <input type="text" id="subject" pattern="[a-zA-Z]+"  title="Take only Alphabets !" maxlength = "12" placeholder="Enter a subject" required > </td>'
          +'<td data-label="Marks"> <input type="number" id="marks" pattern="[0-9]+" min="0" max="100" placeholder="Enter a Marks" required > </td>'
          +'<td data-label="Status"> <a class="btn btn-success btn1 me-1" id="btn_pass">Accept</a><a class="btn btn-danger btn2">Reject</a> </td>'
          +'<td data-label="Action"> <button class="btn delete" type="button" ><span> <img src="image/remove.jpg" w-100 class="rounded-circle" alt=""> </span></button> </td></tr>');
      })

      //Delete Row
        $('#StudentData').on('click','.delete',function(){
          let confirm1 = confirm("Are you sure you want to delete?");
          if(confirm1){ $(this).parent().parent().remove(); }
        })
