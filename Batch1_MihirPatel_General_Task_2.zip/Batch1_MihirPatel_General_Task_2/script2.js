
const table = $('#myTable').DataTable();

let EditRow;
$("#adddata").click(function(){
    $("#update").hide();
    $("#submit").show();
    $('#myForm')[0].reset();

  });


$("#myTable").on('click','.Edit',function () {
    
    $("#update").show();
    $("#submit").hide();
        // console.log(  $(this).closest('tr'));
        let val1= $(this).closest('tr').children('td:eq(1)').html()
        let val2=$(this).closest('tr').children('td:eq(2)').html()
        let val3=$(this).closest('tr').children('td:eq(3)').html()
        // console.log(val1);
        // console.log(val2);
        // console.log(val3);
        $('#name_id').val(val1)
        $('#age_id').val(val2)
        $('#designation_id').val(val3)
        EditRow = $(this).closest('tr');
})

  $('#update').click( function () {
            //alert("hello")
            let val1=EditRow.children('td:eq(1)')
            let val2=EditRow.children('td:eq(2)')
            let val3=EditRow.children('td:eq(3)')
            let nameV = $('#name_id').val()
            let ageV = $('#age_id').val()
            let designationV = $('#designation_id').val()
            val1.html(nameV);
            val2.html(ageV);
            val3.html(designationV);
            $('#close').click();

  })

// $("#myTable").on('click','.Delete',function () {

//     let cRow = $(this).closest('tr');

//     table.row(cRow).remove();
// table.draw();

// })

function Delete(e){
    let cRow = e.closest('tr');
    table.row(cRow).remove();
    table.draw();
}

$(document).ready(function () {
    var forms = $('.needs-validation');
    forms.each(function () {
        var form = this;
       
        form.addEventListener('submit', function (event) {
            if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }
            // else{
            form.classList.add('was-validated');
            if(form.checkValidity() === true){
                event.preventDefault();
                var person = {
                    id:' <p class="counterCell"></p>',
                    name : $('#name_id').val(),
                    age : $('#age_id').val(),
                    Designation : $('#designation_id').val(),
                    Action:'<button class="btn btn-info Edit"  data-toggle="modal" data-target="#myModal">Edit</button>&nbsp;'+
                    '<button class="btn btn-danger Delete" onclick="Delete(this)">Delete</button>'
                }

              console.log(person)
                // $('#myTable').DataTable();

                // const table = $('#myTable').DataTable();
                // for (const person of form_data) {
                  table.row.add([person.id,person.name, person.age, person.Designation,person.Action]).draw(false);

                // }
                // console.log(form_data);
                $('#myForm')[0].reset();
                $('#myForm').removeClass("was-validated");
                $('#close').click();

            }
        // }
        });

 
        
    });



    $('#name_id').keypress(function (e) {
        var regex = new RegExp(/^[a-zA-Z][a-zA-Z ]*/);
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
            return true;
        }
        else {
            e.preventDefault();
            return false;
        }
    });



    $("#name_id").keypress(function ValidateAlpha(evt) {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
          return false;
       
      })


      $("#designation_id").keypress(function ValidateAlpha(evt) {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
          return false;
        
      })

      

});

